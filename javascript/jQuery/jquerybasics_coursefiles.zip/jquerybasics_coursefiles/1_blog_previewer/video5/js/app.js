$('#flashMessage')
  .hide()
  .slideDown(1000)
  .delay(3000)
  .slideUp();
