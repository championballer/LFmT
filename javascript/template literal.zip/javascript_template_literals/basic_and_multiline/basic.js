const singleQuotes = '<p>Single quotes</p>';
const doubleQuotes = "<p>Double quotes</p>";

const result = singleQuotes + doubleQuotes;
//document.querySelector('.basic').innerHTML = result;
